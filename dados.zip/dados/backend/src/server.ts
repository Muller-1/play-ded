import express from 'express';
import fs from 'fs';
import path from 'path';
import cors from 'cors'; // Importante para o Angular conseguir falar com o Node

import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Recriando as variáveis de caminho para o padrão ES Module
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.json());
app.use(cors()); // Permite que seu frontend acesse o backend


// Agora o seu código original vai funcionar:
const FICHAS_DIR = path.join(__dirname, '..', 'fichas');

// Garantir que a pasta de fichas existe
if (!fs.existsSync(FICHAS_DIR)) {
    fs.mkdirSync(FICHAS_DIR);
}

// ROTA: Salvar Ficha
app.post('/api/fichas', (req, res) => {
    const ficha = req.body;
    const nomeArquivo = `${ficha.nome.toLowerCase().replace(/\s+/g, '_')}.json`;
    const caminho = path.join(FICHAS_DIR, nomeArquivo);

    fs.writeFile(caminho, JSON.stringify(ficha, null, 2), (err) => {
        if (err) return res.status(500).json({ erro: 'Erro ao salvar ficha' });
        res.json({ mensagem: `Ficha de ${ficha.nome} salva com sucesso!` });
    });
});

app.listen(3000, () => console.log('Backend RPG rodando na porta 3000'));